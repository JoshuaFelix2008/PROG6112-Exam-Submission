/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.salesreport;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author joshu
 */
public class ProductTest {
    
    private Product product;
    
    @BeforeEach
    public void setUp() {

        String[] products = {"Cozy Nights Monarch","Restonic Barbados","Sealy Phuket"};

        int[][] sales = {
                {25, 18, 20}, // Total = 63
                {15, 10, 12}, // Total = 37
                {18, 15, 20}  // Total = 53
        };

        product = new Product(products, sales);
    }
    
    @Test
    public void GetTotalProductSales_WithValidData_ReturnsCorrectValue() {
        
        // Theexpected total sales will be 63 + 37 + 53 = 153
        int expected = 153;
        
        int actual = product.GetTotalProductsSold();
        
        assertEquals(expected, actual);
    }
    
    @Test 
    public void GetAverageSales_WithValidData_ReturnsCorrectValue() {
        
        //  The expected average = 153 /3 = 51
        double expected = 51.0;
        
        double actual = product.GetAverageProductSold();
        
        assertEquals(expected, actual);
    }
}
