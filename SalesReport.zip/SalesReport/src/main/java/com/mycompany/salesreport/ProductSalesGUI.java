/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.salesreport;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;
/**
 *
 * @author joshu
 */
public class ProductSalesGUI extends JFrame implements ActionListener{
    
    // Declaring variables
    private JTextField txtCustomerName;
    private JTextField txtPrice;
    private JComboBox<String> cmbProducts;
    private JButton btnProcess;
    private JMenuBar menuBar;
    private JMenu fileMenu;
    private JMenu toolsMenu;
    private JMenuItem exitItem;
    private JMenuItem processItem;
    private JMenuItem clearItem;
    
    public ProductSalesGUI() {
        
        // Adding panels for the menu
        setTitle("Product App");
        setSize(500, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        JPanel panel = new JPanel();
        panel.setLayout(null);
        
        JLabel lblCustomer = new JLabel("Customer Name:");
        lblCustomer.setBounds(30, 40, 120, 25);
        panel.add(lblCustomer);
        
        txtCustomerName = new JTextField();
        txtCustomerName.setBounds(150, 40, 220, 25);
        panel.add(txtCustomerName);
        
        JLabel lblProduct = new JLabel("Select Product:");
        lblProduct.setBounds(30, 90, 120, 25);
        panel.add(lblProduct);
        
        String [] products = {"Cozy nights Monarch mattress", "Restonic Barbados mattress", "Sealy Phuket mattress"};
        
        cmbProducts = new JComboBox<>(products);
        cmbProducts.setBounds(150, 90, 220, 25);
        panel.add(cmbProducts);
        
        JLabel lblPrice = new JLabel("Enter Price:");
        lblPrice.setBounds(30, 140, 120, 25);
        panel.add(lblPrice);
        
        txtPrice = new JTextField();
        txtPrice.setBounds(150, 140, 220, 25);
        panel.add(txtPrice);
        
        btnProcess = new JButton("PROCESS");
        btnProcess.setBounds(150, 190, 220, 30);
        btnProcess.addActionListener(this);
        panel.add(btnProcess);
        
        menuBar = new JMenuBar();

        fileMenu = new JMenu("File");
        toolsMenu = new JMenu("Tools");

        exitItem = new JMenuItem("Exit");
        processItem = new JMenuItem("Process");
        clearItem = new JMenuItem("Clear");

        fileMenu.add(exitItem);

        toolsMenu.add(processItem);
        toolsMenu.add(clearItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);

        setJMenuBar(menuBar);
        
        add(panel);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        
         try {
             
            String customerName = txtCustomerName.getText();
            String product = cmbProducts.getSelectedItem().toString();

            double price = Double.parseDouble(txtPrice.getText());

            double vat = price * 0.15;
            double commission = price * 0.05;
            double total = price + vat + commission;
            
            // Results are displayed here.
            String message = "Customer Name: " + customerName + "\nProduct: " + product + "\nVAT: R " + vat + "\nCOMMISSION: R " + commission + "\nTOTAL: R " + total;
            
            JOptionPane.showMessageDialog(this, message, "Message", JOptionPane.INFORMATION_MESSAGE);
            
            exitItem.addActionListener(this);
            processItem.addActionListener(this);
            clearItem.addActionListener(this);
            
            // Used to save information to a file
            FileWriter writer = new FileWriter("data.txt", true);
            
            writer.write("DATA LOG\n");
            writer.write("******************************\n");
            writer.write("Customer Name: " + customerName + "\n");
            writer.write("Product: " + product + "\n");
            writer.write("VAT: R " + vat + "\n");
            writer.write("COMMISSION: R " + commission + "\n");
            writer.write("TOTAL: R " + total + "\n");
            writer.write("******************************\n");
            
            writer.close();
            
        } 
        catch(NumberFormatException ex) {

        JOptionPane.showMessageDialog(
                this,
                "Please enter a valid price.");
        }
        catch(Exception ex) {
            
            JOptionPane.showMessageDialog(
                this,
                "Error saving data to file.");
        }
    }
    
    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {
            new ProductSalesGUI().setVisible(true);
        });
    }
}
