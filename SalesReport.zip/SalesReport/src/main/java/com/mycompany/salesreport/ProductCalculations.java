/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.salesreport;

/**
 *
 * @author joshu
 */
public class ProductCalculations implements IProductCalculations {
    
    private double price;
    
    public ProductCalculations(double price) {
        this.price = price;
    }
    
    // Vat included
    @Override
    public double GetVat() {
        return price * 0.15;
    }
    
    // Commission
    @Override
    public double GetCommission() {
        return price * 0.05;
    }
    
    // New total
    @Override
    public double GetTotal() {
        return price + GetVat() + GetCommission();
    }
}
