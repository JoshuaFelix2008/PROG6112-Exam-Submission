/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.salesreport;
import java.util.Scanner;
/**
 *
 * @author joshu
 */
public class SalesReport {

    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        
        // Adding Product Names
        String [] products = {"Cozy nights Monarch mattress", "Restonic Barbados mattress", "Sealy Phuket mattress"};
        
        // Sales data using 2 dimnesional array
        int[][] sales = new int[3][3];
        
        // The stores total sales per product
        int[] productTotals = new int[3];
        
        // The input sales for each product and month
        for (int product = 0; product < products.length; product++) {
            
            for (int month = 0; month < 3; month++) {
                
                System.out.print("Enter number of sales for month " + (month + 1) + "for " + products[product] + ": ");
                
                sales[product][month] = input.nextInt();
                
                productTotals[product] += sales[product][month];
            }
            
            System.out.println();
        }
        
        // Total number of products sold
        int totalSales = 0;
        
        for (int total : productTotals) {
            totalSales += total;
        }
        
        // Average number of products sold per product
        double averageSales = (double) totalSales / products.length;
        
        // Most popular product
        int highestSales = productTotals[0];
        int popularIndex = 0;
        
        for (int i = 1; i < productTotals.length; i++) {
            
            if (productTotals[i] > highestSales) {
                highestSales = productTotals[i];
                popularIndex = i;
            }
        }
        
        // Report displayed
        System.out.println("\nPRODUCT SALES REPORT - 2026");
        System.out.println("****************************************");

        System.out.println("TOTAL PRODUCT SALES: " + totalSales);
        System.out.printf("AVERAGE PRODUCT SALES: %.0f%n", averageSales);

        System.out.println("MOST POPULAR PRODUCT: "
                + products[popularIndex]
                + " (" + highestSales + ")");

        input.close();
        
        // Sales are captured
        for (int product = 0; product < products.length; product++) {

            for (int month = 0; month < 3; month++) {

                System.out.print("Enter number of sales for month "
                        + (month + 1)
                        + " for "
                        + products[product]
                        + " mattress: ");

                sales[product][month] = input.nextInt();
            }

            System.out.println();
        }

        Product productReport = new Product(products, sales);

        PrintProduct printer = new PrintProduct();

        System.out.println("\nPRODUCT SALES REPORT - 2026");
        System.out.println("****************************************");

        printer.PrintTotalSales(productReport);
        printer.PrintAverageSales(productReport);
        printer.PrintMostPopularProduct(productReport);

        input.close();
    }
    
}
